#ifndef _RAR_FN_
#define _RAR_FN_

void RARInitData();


#endif
